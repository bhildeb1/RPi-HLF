package main

import (
   "fmt"
   "os"
   "crypto/x509"
   "github.com/hyperledger/fabric-gateway/pkg/client"
   "github.com/hyperledger/fabric-gateway/pkg/hash"
   "github.com/hyperledger/fabric-gateway/pkg/identity"
   "google.golang.org/grpc"
   //"google.golang.org/grpc/credentials"
   "google.golang.org/grpc/credentials/insecure"
)

const creatorOrg = "Org1MSP"
const peerAddr = "dns:///peer0.org1.kalima.com:7051"


func main() {
   clientConnection, err := NewGrpcConnection()
   panicOnError(err)
   defer clientConnection.Close()
   id := NewIdentity()
   sign := NewSign()

   gateway, err := client.Connect(id, client.WithSign(sign), client.WithHash(hash.SHA256), client.WithClientConnection(clientConnection))
   panicOnError(err)
   defer gateway.Close()
   network := gateway.GetNetwork("aether")
   contract := network.GetContract("kalima")

   fmt.Printf("gateway: %v\n", gateway)
   fmt.Printf("network: %v\n", network)
   fmt.Printf("contract: %v\n", contract)

   result, err := contract.EvaluateTransaction("QueryAllIssues")
   panicOnError(err)
   fmt.Printf("result: %s\n\n", string(result))
}

func NewGrpcConnection() (*grpc.ClientConn, error) {
   // client.crt
   pemBytes, err := os.ReadFile("client.crt")
   panicOnError(err)

   certPool := x509.NewCertPool()

   ok := certPool.AppendCertsFromPEM(pemBytes)

   if !ok {
      fmt.Printf("failed to append certs from pem file")
   }

   //certPool.AddCert(tlsCertificatePEM)
   //transportCredentials := credentials.NewClientTLSFromCert(certPool, "")

   transportCredentials := insecure.NewCredentials()

   return grpc.NewClient(peerAddr, grpc.WithTransportCredentials(transportCredentials))
   //return grpc.NewClient(peerAddr, grpc.WithTransportCredentials(insecure.NewCredentials()))
   //return grpc.NewClient(peerAddr, grpc.WithInsecure())
}

func NewIdentity() *identity.X509Identity {
   // ca.crt
   //certificatePEM, err := os.ReadFile("ca.crt")
   certificatePEM, err := os.ReadFile("client.crt")
   panicOnError(err)

   certificate, err := identity.CertificateFromPEM(certificatePEM)
   panicOnError(err)

   //id, err := identity.NewX509Identity("Org1MSP", certificate)
   id, err := identity.NewX509Identity(creatorOrg, certificate)

   panicOnError(err)

   return id
}

func NewSign() identity.Sign {
   // client.key
   privateKeyPEM, err := os.ReadFile("client.key")
   panicOnError(err)

   privateKey, err := identity.PrivateKeyFromPEM(privateKeyPEM)
   panicOnError(err)

   sign, err := identity.NewPrivateKeySign(privateKey)
   panicOnError(err)

   return sign
}


func panicOnError(err error) {
   if err != nil {
      panic(err)
   }
}

