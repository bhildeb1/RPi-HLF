#!/bin/bash

CHAINCODE_NAME="${1:-kalima}"

# helper functions

function output_heading {
   echo
   echo "-------------------------------------------------------------------------------"
   echo
   echo "$1"
   echo
   echo "-------------------------------------------------------------------------------"
   echo
}

function pause {
   echo
   read -p "Press ENTER to continue or X to exit: " choice
   choice="${choice^^}" # convert to uppercase
   echo

   if [ "$choice" = "X" ]; then
      echo "Exiting script ..."
      echo
      exit
   fi
}

# multi-line comment:
#if false; then
#...
#fi

# (1) package chaincode
output_heading "(1) package chaincode"

peer lifecycle chaincode package ${CHAINCODE_NAME}.tar.gz \
     --path ./kalimaHLF/ \
     --label ${CHAINCODE_NAME}
     #-o orderer.kalima.com:7050
pause

# (2) install chaincode
output_heading "(2) install chaincode"
peer lifecycle chaincode install ${CHAINCODE_NAME}.tar.gz
#-o orderer.kalima.com:7050
pause

# if install fails, wait 10 min; new chaincode will appear as installed under queryinstalled

# (3) query installed chaincode
output_heading "(3) query installed chaincode"
peer lifecycle chaincode queryinstalled
pause

# (4) get package id
output_heading "(4) get package id"

REGEX="Package ID: (.*), Label: ${CHAINCODE_NAME}"
echo "REGEX:"
echo $REGEX
if [[ `peer lifecycle chaincode queryinstalled` =~ $REGEX ]]; then
   PACKAGE_ID=${BASH_REMATCH[1]}
   echo "Package ID: ${PACKAGE_ID}"
else
   echo "unable to find package ID"
fi

echo "Package ID: ${PACKAGE_ID}"

pause

# (5) approve chaincode for org
output_heading "(5) approve chaincode for org"

peer lifecycle chaincode approveformyorg \
     -C aether \
     -n ${CHAINCODE_NAME} \
     -v 1.0 \
     --sequence 1 \
     --package-id ${PACKAGE_ID}

pause

# (6) check chaincode commit readiness
output_heading "(6) check chaincode commit readiness"

peer lifecycle chaincode checkcommitreadiness \
     -C aether \
     -n ${CHAINCODE_NAME} \
     -v 1.0 \
     --sequence 1 \
     --output json

pause

# (7) commit chaincode to channel
output_heading "(7) commit chaincode to channel"

peer lifecycle chaincode commit \
     -C aether \
     -n ${CHAINCODE_NAME} \
     -v 1.0 \
     --sequence 1 \
     --peerAddresses peer0.org1.kalima.com:7051

pause

# (8) query chaincode definitions
output_heading "(8) query chaincode definitions"

peer lifecycle chaincode querycommitted -C aether
pause
peer lifecycle chaincode querycommitted -C aether -n ${CHAINCODE_NAME}
pause

# (9) invoke chaincode and init ledger
output_heading "(9) invoke chaincode and init ledger"

peer chaincode invoke \
     -o orderer.kalima.com:7050 \
     -C aether \
     -n ${CHAINCODE_NAME} \
     --peerAddresses peer0.org1.kalima.com:7051 \
     -c '{"function":"InitLedger","Args":[]}'
pause

# (10) query all candidates
output_heading "(10) query all candidates"
INVOKE_FUNCTION='{"function":"queryAllCandidates","Args":[]}'

peer chaincode query \
     -C aether \
     -n ${CHAINCODE_NAME} \
     -c ${INVOKE_FUNCTION} \
     | jq .
pause

peer chaincode invoke \
     -C aether \
     -n ${CHAINCODE_NAME} \
     -c ${INVOKE_FUNCTION} \
pause
