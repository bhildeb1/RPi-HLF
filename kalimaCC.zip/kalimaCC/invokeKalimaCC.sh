#!/bin/bash

PARAM1="${1:-help}"
CHAINCODE_NAME="kalimah"
CHANNEL_NAME="aether"

# helper functions

function output_heading {
   echo
   echo "-------------------------------------------------------------------------------"
   echo
   echo "$1"
   echo
   echo "-------------------------------------------------------------------------------"
   echo
}

function pause {
   echo
   read -p "Press ENTER to continue or X to exit: " choice
   choice="${choice^^}" # convert to uppercase
   echo

   if [ "$choice" = "X" ]; then
      echo "Exiting script ..."
      echo
      exit
   fi
}

# multi-line comment:
#if false; then
#...
#fi

HELP_DOCUMENTATION="\nKalimaHLF Reference:\n\
Use provided bash scrips (or write your own) to interact with KalimaHLF Blockchain\n\
\n\
View all candidates     ./invokeKalimaHLF.sh candidates \n\
View all issues         ./invokeKalimaHLF.sh issues \n\
View all votes          ./invokeKalimaHLF.sh votes \n\
\n\
View candidate by id:   ./invokeKalimaHLF.sh candidate [candidate id] \n\
View issue by id:       ./invokeKalimaHLF.sh issue [issue id] \n\
View vote by id:        ./invokeKalimaHLF.sh vote [vote id] \n\
\n\
Add candidate:          ./invokeKalimaHLF.sh addCandidate [first name] [last name] [party] \n\
Add issue:              ./invokeKalimaHLF.sh addIssue [issue name] \n\
Add vote:               ./invokeKalimaHLF.sh addVote [voter id] [candidate id] [issue id] \n\
Update candidate:       ./invokeKalimaHLF.sh updateCandidate [candidate id] [first name] \n\
                                                             [last name] [party] \n\
Update issue:           ./invokeKalimaHLF.sh updateIssue [issue id] [issue name] \n\
\n\
Tally candidate votes:  ./invokeKalimaHLF.sh tallyCandidateVotes [candidate id] \n\
Tally issue votes:      ./invokeKalimaHLF.sh tallyIssueVotes [issue id] \n\
Verify vote:            ./invokeKalimaHLF.sh verifyVote [voter id] \n"


if [ $PARAM1 == "candidates" ]; then
     #echo "candidates"
     # (1) query all candidates
     output_heading "(1) query all candidates"
     INVOKE_FUNCTION='{"function":"queryAllCandidates","Args":[]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq . | less
elif [ $PARAM1 == "issues" ]; then
     #echo "issues"
     # (2) query all issues
     output_heading "(2) query all issues"
     INVOKE_FUNCTION='{"function":"queryAllIssues","Args":[]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq . | less
elif [ $PARAM1 == "votes" ]; then
     # (3) query all votes
     output_heading "(3) query all votes"
     INVOKE_FUNCTION='{"function":"queryAllVotes","Args":[]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq . | less
elif [ $PARAM1 == "candidate" ]; then
     # (4) view candidate
     output_heading "(4) view candidate"
     candidateID="${2:-C000002}"
     INVOKE_FUNCTION='{"function":"viewCandidate","Args":["'$candidateID'"]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq .
elif [ $PARAM1 == "issue" ]; then
     # (5) view issue
     output_heading "(5) view issue"
     issueID="${2:-I000002}"
     INVOKE_FUNCTION='{"function":"viewIssue","Args":["'$issueID'"]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq .
elif [ $PARAM1 == "vote" ]; then
     # (6) view vote
     output_heading "(6) view vote"
     voteID="${2:-V000002}"
     INVOKE_FUNCTION='{"function":"viewVote","Args":["'$voteID'"]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION} | jq .
elif [ $PARAM1 == "addCandidate" ]; then
     # (7) add candidate
     output_heading "(7) add candidate"
     candidateID="C0000$((RANDOM % 10))$((RANDOM % 10))"
     firstName="${2:-Alec}"
     lastName="${3:-Guinness}"
     party="${4:-independent}"
     INVOKE_FUNCTION='{"function":"addCandidate","Args":["'$candidateID'","'$firstName'","'$lastName'","'$party'"]}'
     peer chaincode invoke -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "addIssue" ]; then
     # (8) add issue
     output_heading "(8) add issue"
     issueID="I0000$((RANDOM % 10))$((RANDOM % 10))"
     issueName="${2:-e-voting}"
     INVOKE_FUNCTION='{"function":"addIssue","Args":["'$issueID'","'$issueName'"]}'
     peer chaincode invoke -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "addVote" ]; then
     # (9) add vote
     output_heading "(9) add vote"
     voteID="V0000$((RANDOM % 10))$((RANDOM % 10))"
     voterID="${2:-E000001}"
     candidateID="${2:-C000001}"
     issueID="${2:-I000002}"
     INVOKE_FUNCTION='{"function":"addVote","Args":["'$voteID'","'$voterID'","'$candidateID'","'$issueID'"]}'
     peer chaincode invoke -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "updateCandidate" ]; then
     # (10) update candidate
     output_heading "(10) update candidate"
     candidateID=$2
     firstName=$3
     lastName=$4
     party="${5:-undeclared}"
     INVOKE_FUNCTION='{"function":"updateCandidate","Args":["'$candidateID'","'$firstName'","'$lastName'","'$party'"]}'
     peer chaincode invoke -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "updateIssue" ]; then
     # (11) update issue
     output_heading "(11) update issue"
     issueID=$2
     issueName=$3
     INVOKE_FUNCTION='{"function":"updateIssue","Args":["'$issueID'","'$issueName'"]}'
     peer chaincode invoke -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "tallyCandidateVotes" ]; then
     # (12) tally candidate votes
     output_heading "(12) tally candidate votes"
     candidateID="C000003"
     INVOKE_FUNCTION='{"function":"tallyCandidateVotes","Args":["'$candidateID'"]}'
     peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "tallyIssueVotes" ]; then
     # (13) tally issue votes
     output_heading "(13) tally issue votes"
     #issueID="I000003"
     #INVOKE_FUNCTION='{"function":"tallyIssueVotes","Args":["'$issueID'"]}'
     #peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
elif [ $PARAM1 == "verifyVote" ]; then
     # (14) verify vote
     output_heading "(14) verify vote"
     #voterID="V000003"
     #INVOKE_FUNCTION='{"function":"verifyVote","Args":["'$voterID'"]}'
     #peer chaincode query -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} -c ${INVOKE_FUNCTION}
     #TODO: query resulting candidateID & issueID & display results
     #TODO: thereafter query viewCandidate & viewIssue & display results
else
     echo -e "${HELP_DOCUMENTATION}"
fi

# TODO: configure tallyCandidateVotes, tallyIssueVotes & verifyVote to work w/ leveldb

